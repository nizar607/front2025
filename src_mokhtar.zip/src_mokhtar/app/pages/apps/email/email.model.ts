export interface Email {
  id?: number;
  starred?: boolean;
  readed?:boolean;
  name?: string;
  counted?: any;
  title?: string;
  description?:any;
  date?: string;
  tabtype?: string;
  labeltype?: string;
  userImg?: string;
}