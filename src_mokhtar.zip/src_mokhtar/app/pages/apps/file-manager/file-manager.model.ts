
export interface filemanagerModel {
    id?: any;
    icon?: any;
    color?: any;
    title?: any;
    item?: any;
    mb?: any;
    date?: any;
}

