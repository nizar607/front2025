export interface customerModel {
    id?: any,
    img: string;
    name: string;
    email?: any,
    phone?: any,
    create_date?: any;
    status?: any;
}
