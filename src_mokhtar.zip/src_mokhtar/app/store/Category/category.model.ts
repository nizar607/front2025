export interface CategoryModel {
  id:number,
  name:string,
  description:string,
  articles:any[]
}
