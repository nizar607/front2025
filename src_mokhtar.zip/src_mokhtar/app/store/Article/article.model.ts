export interface ArticleModel {
  id:number,
  name:string,
  description:string,
}
