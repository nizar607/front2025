export class User {
  status?:string;
  token?:string;
  data:any;
  /*id?: string;
  username?: string;
  password?: string;
  firstName?: string;
  lastName?: string;
  token?: string;
  email?: string;*/
}
