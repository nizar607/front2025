export interface ListModel {
    id?: any;
    invoice_no?: any;
    customer?: any;
    email?: any;
    createDate?: any;
    dueDate?: any;
    invoice_amount?: any;
    status?: any;
}

export interface InvoiceModel {
    id?: any;
    color?: any;
    title?: any;
    icon?: any;
    iconColor?: any;
    dueDate?: any;
    amout?: any;
    count?: any;
}